//
//  BoardModel.swift
//  GameLogic
//
//  Created by Seungeun Park on 7/18/25.
//

class BoardModel {
    let route1 : [String] = ["start","_6_6", "_5_6", "_4_6", "_2_6", "_1_6", "_0_6", "_0_5", "_0_4", "_0_2", "_0_1", "_0_0", "_1_0", "_2_0", "_4_0", "_5_0", "_6_0", "_6_1", "_6_2", "_6_4", "_6_5", "_6_6", "end"]
    let route2 : [String] = ["start","_6_6", "_5_6", "_4_6", "_2_6", "_1_6", "_0_6", "_0_5", "_0_4", "_0_2", "_0_1", "_0_0","_1_1", "_2_2", "_3_3", "_4_4", "_5_5", "_6_6", "end"]
    let route3 : [String] = ["start","_6_6", "_5_6", "_4_6", "_2_6", "_1_6", "_0_6", "_1_5", "_2_4", "_3_3", "_4_2", "_5_1", "_6_0", "_6_1", "_6_2", "_6_4", "_6_5", "_6_6", "end"]
//    let route4 : [String] = ["_6_6", "_5_6", "_4_6", "_2_6", "_1_6", "_0_6",  "_1_5", "_2_4", "_3_3", "_4_4", "_5_5", "_6_6", "end"]
    
    var routes : [[String]] {
        [route1, route2, route3]
    }
    
    var branchRouteOptions: [String: [Int]] = [
        "_0_6" : [0, 2],
        "_0_0" : [0, 1],
        "_3_3" : [1, 2]
    ]
    
    func availableRouteIndicate(at cellID: String, currentRoute: Int) -> [Int] {
        if let branches = branchRouteOptions[cellID] {
            return branches // 갈 수 있는 분기점 반환
        } else {
            return [currentRoute] // 기존 루트 유지
        }
    }
}

