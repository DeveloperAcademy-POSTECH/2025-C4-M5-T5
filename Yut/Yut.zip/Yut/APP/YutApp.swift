//
//  YutApp.swift
//  Yut
//
//  Created by Jay on 7/11/25.
//

import SwiftUI

@main
struct YutApp: App {
    var body: some Scene {
        WindowGroup {
            PlayView()
//            RootView()
        }
    }
}
