//
//  YutTests.swift
//  YutTests
//
//  Created by Jay on 7/11/25.
//

import Testing
@testable import Yut

struct YutTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
